# Example Customer UDF



## Init Repo

```shell
$ uv init --lib
```

### Add SCP Runtime Constraints

Append this to the `pyproject.toml`. This is derived from the

```toml
[tool.uv]
constraint-dependencies = [
    "apache-flink>=2.1.0",
    "confluent-function-runtime-core>=0.161.0",
    "protobuf>=5.29.0",
    "click>=8.2.0",
    "confluent-function-runtime-core>=0.161.0",
    "grpc-interceptor>=0.15.0",
    "grpcio-health-checking>=1.59.0",
    "grpcio-reflection>=1.59.0",
    "grpcio>=1.59.0",
    "typing_extensions>=4.4.0",
]
```

## Add User Dependencies

```shell
$ uv add 'apache-flink>=2.1.0' grpcio
```

This will error out if we cannot reconcile SCP deps and user deps.

## Create Zip

```shell
$ uv build --sdist
$ cd dist
dist $ mkdir tmp
dist $ tar -xf example_udf-0.1.0.tar.gz -C tmp
dist $ (cd tmp; zip -r ../example_udf-0.1.0.zip .)
dist $ rm -rf tmp
```

This creates `dist/example_udf-0.1.0.zip`.
